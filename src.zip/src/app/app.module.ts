import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppComponent } from './app.component';
import { ProductComponent } from './product/product.component';
import { TransactionJournalComponent } from './transaction-journal/transaction-journal.component';
import { HttpClientModule } from '@angular/common/http';/*added for to read json*/
@NgModule({
  declarations: [
    AppComponent,
    ProductComponent,
    TransactionJournalComponent
  ],
  imports: [
    BrowserModule,
    HttpClientModule   /*added for to read json*/
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
