import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { HttpErrorResponse } from '@angular/common/http';
@Component({
  selector: 'app-transaction-journal',
  templateUrl: './transaction-journal.component.html',
  styleUrls: ['./transaction-journal.component.css']
})
export class TransactionJournalComponent implements OnInit {

  constructor (private httpService: HttpClient) { }
  TJDetails: string [];

  ngOnInit () {
    this.httpService.get('./assets/new.json').subscribe(
      data => {
        this.TJDetails = data as string [];	 

        
        // FILL THE ARRAY WITH DATA.
        console.log(this.TJDetails.AccountDetail.Option);
       
      },
      (err: HttpErrorResponse) => {
        console.log (err.message);
      }
    );
    /*this.httpService.get('./assets/SecondDetail.json').subscribe(
      data => {
        this.SecondDetail = data as string [];	 // FILL THE ARRAY WITH DATA.
         console.log(this.SecondDetail[1]);
      },
      (err: HttpErrorResponse) => {
        console.log (err.message);
      }
    );*/
  }

}
