import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { TransactionJournalComponent } from './transaction-journal.component';

describe('TransactionJournalComponent', () => {
  let component: TransactionJournalComponent;
  let fixture: ComponentFixture<TransactionJournalComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ TransactionJournalComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(TransactionJournalComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
